package com.example.cameratrapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.text.method.ScrollingMovementMethod;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements ExampleDialog.ExampleDialogListener, PopupMenu.OnMenuItemClickListener {

    //implements ExampleDialog.ExampleDialogListener
    //implements PopupMenu.OnMenuItemClickListener
    EditText editTextAddress, editTextPort;
    Button buttonConnect, buttonDisconnect;
    Button buttonManual, buttonPowerCheck;
    Button buttonStartMaster, buttonDebug, buttonTestMessage;
    Button buttonCheckCamera, buttonMovePictures;
    TextView textViewState, textViewRx;

    ClientHandler clientHandler;
    ClientThread clientThread;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_main);
//        editTextAddress = (EditText) findViewById(R.id.address);
//        editTextPort = (EditText) findViewById(R.id.port);
//        editTextMsg = (EditText) findViewById(R.id.msgtosend);



        //Buttons
//      buttonConnect = (Button) findViewById(R.id.connect);
        buttonDisconnect = (Button) findViewById(R.id.disconnect);
//        buttonSend = (Button) findViewById(R.id.send);
        buttonManual = (Button)findViewById(R.id.manualTest);
//        buttonTake = (Button)findViewById(R.id.take);
        buttonPowerCheck = (Button)findViewById(R.id.powerCheck);
//        buttonSSHCheck = (Button)findViewById(R.id.sshCheck);
        buttonStartMaster = (Button)findViewById(R.id.startMaster);
        buttonDebug = (Button)findViewById(R.id.exampleButton);
//        buttonTestMessage = (Button)findViewById(R.id.testMessage);
//        buttonCheckCamera = (Button)findViewById(R.id.checkCamera);
        buttonMovePictures = (Button)findViewById(R.id.movePictures);




        textViewState = (TextView)findViewById(R.id.state);
        textViewRx = (TextView)findViewById(R.id.received);
        textViewRx.setMovementMethod(new ScrollingMovementMethod());

        buttonDisconnect.setEnabled(false);
//        buttonSend.setEnabled(false);

        /**
         * Button Click Listeners
         * */
//        buttonConnect.setOnClickListener(buttonConnectOnClickListener);
        buttonDisconnect.setOnClickListener(buttonDisConnectOnClickListener);
//        buttonSend.setOnClickListener(buttonSendOnClickListener);
        buttonManual.setOnClickListener(buttonManualOnClickListener);
//        buttonTake.setOnClickListener(buttonTakeOnClickListener);
        buttonPowerCheck.setOnClickListener(buttonPowerCheckOnClickListener);
//        buttonSSHCheck.setOnClickListener(buttonSSHCheckOnClickListener);
        buttonStartMaster.setOnClickListener(buttonStartMasterOnClickListener);
//        buttonDebug.setOnClickListener(buttonDebugOnClickListener);
//        buttonTestMessage.setOnClickListener(buttonTestMessageOnClickListener);
//        buttonCheckCamera.setOnClickListener(buttonCheckCameraOnClickListener);
        buttonMovePictures.setOnClickListener(buttonMovePicturesOnClickListener);


        Intent intent = getIntent();
        String ipAddress = intent.getStringExtra("ipAddress");
        String portNum = intent.getStringExtra("portNum");



        clientHandler = new ClientHandler(this);


        clientThread = new ClientThread(
                ipAddress,
                Integer.parseInt(portNum),
                clientHandler);
        clientThread.start();

        buttonDisconnect.setEnabled(true);
//        buttonSend.setEnabled(true);
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch ( item.getItemId()) {
            case R.id.item1:
//                textViewRx.append("TEST: Send Sample Picture (picture)" + "\n");
                Toast.makeText(this, "TEST: Send Sample Picture", Toast.LENGTH_SHORT).show();
                clientThread.txMsg("picture");
                return true;
            case R.id.item2:
//                textViewRx.append("TEST: Take Photo and Send (take)" + "\n");
                Toast.makeText(this, "TEST: Take Photo and Send", Toast.LENGTH_SHORT).show();
                clientThread.txMsg("take");
                return true;
            case R.id.item3:
//                textViewRx.append("TEST: SSH Connection (sshCheck)" + "\n");
                Toast.makeText(this, "TEST: SSH Connection", Toast.LENGTH_SHORT).show();
                clientThread.txMsg("sshCheck");
                return true;
            case R.id.item4:
//                textViewRx.append("TEST: Camera Connection (checkCamera)" + "\n");
                Toast.makeText(this, "TEST: Camera Connection", Toast.LENGTH_SHORT).show();
                clientThread.txMsg("checkCamera");
                return true;
            case R.id.item5:
//                textViewRx.append("TEST: Sample Message (testMessage)" + "\n");
                Toast.makeText(this, "TEST: Sample Message", Toast.LENGTH_SHORT).show();
                clientThread.txMsg("testMessage");
                return true;
            default:
                return false;


        }
    }

    public void showPopup(View v){
        System.out.println("Show Popup Triggered");
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

//    View.OnClickListener buttonConnectOnClickListener =
//            new View.OnClickListener() {
//
//                @Override
//                public void onClick(View arg0) {
//
//
//                    Intent intent = getIntent();
//                    String ipAddress = intent.getStringExtra("ipAddress");
//                    String portNum = intent.getStringExtra("portNum");
//
//                    clientThread = new ClientThread(
//                            ipAddress,
//                            Integer.parseInt(portNum),
//                            clientHandler);
//                    clientThread.start();
//
//                    buttonConnect.setEnabled(false);
//                    buttonDisconnect.setEnabled(true);
//                    buttonSend.setEnabled(true);
//                }
//            };

    View.OnClickListener buttonDisConnectOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(clientThread != null){
                clientThread.setRunning(false);
                clientThread.txMsg("Disconnecting...");
            }


        }
    };

    View.OnClickListener buttonManualOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            openDialog();
            System.out.println("Client Side: Take Picture");
//            clientThread.txMsg("picture");
        }
    };

    private void openDialog() {
        ExampleDialog exampleDialog = new ExampleDialog();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }

//    View.OnClickListener buttonTakeOnClickListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            System.out.println("Client Side: Take Picture and Move");
//            clientThread.txMsg("take");
//        }
//    };

    View.OnClickListener buttonPowerCheckOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.out.println("Client Side: Power Check");
            clientThread.txMsg("powerCheck");
        }
    };

    View.OnClickListener buttonSSHCheckOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.out.println("Client Side: SSH Check");
            clientThread.txMsg("sshCheck");
        }
    };

    View.OnClickListener buttonStartMasterOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.out.println("Client Side: Starting Master...");
            clientThread.txMsg("startMaster");
        }
    };

//    View.OnClickListener buttonDebugOnClickListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            System.out.println("Client Side: Checking Connections to Master");
//            clientThread.txMsg("checkConnection");
//        }
//    };

    View.OnClickListener buttonTestMessageOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.out.println("Client Side: Testing Message");
            clientThread.txMsg("testMessage");
        }
    };

    View.OnClickListener buttonCheckCameraOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.out.println("Client Side: Checking Camera");
            clientThread.txMsg("checkCamera");
        }
    };

    View.OnClickListener buttonMovePicturesOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.out.println("Client Side: Moving Pictures...");
            clientThread.txMsg("movePictures");
        }
    };


//    View.OnClickListener buttonSendOnClickListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            if(clientThread != null){
//                String msgToSend = editTextMsg.getText().toString();
//                clientThread.txMsg(msgToSend);
//            }
//        }
//    };

    private void updateState(String state){
        textViewState.setText(state);
    }

    private void updateRxMsg(String rxmsg){
        textViewRx.append(rxmsg + "\n");
    }

    private void clientEnd(){
        clientThread = null;
        textViewState.setText("clientEnd()");
//        buttonConnect.setEnabled(true);
        buttonDisconnect.setEnabled(false);
//        buttonSend.setEnabled(false);


        buttonManual.setEnabled(false);
//        buttonTake.setEnabled(false);
        buttonPowerCheck.setEnabled(false);
//        buttonSSHCheck.setEnabled(false);
        buttonStartMaster.setEnabled(false);
        buttonDebug.setEnabled(false);
//        buttonTestMessage.setEnabled(false);
//        buttonCheckCamera.setEnabled(false);
        buttonMovePictures.setEnabled(false);
    }

    @Override
    public void applyTexts(String code) {
//        textViewRx.append(code + "\n");
        clientThread.txMsg(code);
    }

    public static class ClientHandler extends Handler {
        public static final int UPDATE_STATE = 0;
        public static final int UPDATE_MSG = 1;
        public static final int UPDATE_END = 2;
        private MainActivity parent;

        public ClientHandler(MainActivity parent) {
            super();
            this.parent = parent;
        }

        @Override
        public void handleMessage(Message msg) {

            switch (msg.what){
                case UPDATE_STATE:
                    parent.updateState((String)msg.obj);
                    break;
                case UPDATE_MSG:
                    parent.updateRxMsg((String)msg.obj);
                    break;
                case UPDATE_END:
                    parent.clientEnd();
                    break;
                default:
                    super.handleMessage(msg);
            }

        }

    }
}