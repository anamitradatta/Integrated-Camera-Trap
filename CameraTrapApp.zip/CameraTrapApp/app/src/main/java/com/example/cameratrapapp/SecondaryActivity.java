package com.example.cameratrapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class SecondaryActivity extends AppCompatActivity {

    Button buttonNext;
    EditText textIP, textPort;
    TextView infoDisplay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);

        buttonNext = (Button) findViewById(R.id.connectBtnIntro);
        textIP = (EditText) findViewById(R.id.ipIntro);
        textPort = (EditText) findViewById(R.id.portIntro);
        infoDisplay = (TextView) findViewById(R.id.statusIntro);


        buttonNext.setOnClickListener(buttonNextClickListener);
    }

    View.OnClickListener buttonNextClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.out.println("Clicked on the Button to Connect!");
            try {
                openMainActivity();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };


    private void openMainActivity() throws InterruptedException {
        System.out.println(textIP.getText().toString());
        System.out.println(textPort.getText().toString());

        if (validate(textIP.getText().toString(), textPort.getText().toString())) {

            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("ipAddress", textIP.getText().toString());
            intent.putExtra("portNum", textPort.getText().toString());
            buttonNext.setEnabled(false);
            TimeUnit.SECONDS.sleep(1);
            startActivity(intent);
        }

    }

    private boolean validate(String ipAddressInput, String portAddressInput) throws InterruptedException {

        infoDisplay.setText("Validating...");
        TimeUnit.SECONDS.sleep(1);

        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        infoDisplay.setText("Checking Connection to Wifi...");
        TimeUnit.SECONDS.sleep(1);
        if (!mWifi.isConnected()) {
            infoDisplay.setText("Please Connect Android to Wifi");
            return false;
        }

        final WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        final WifiInfo connectionInfo = wifiManager.getConnectionInfo();
        String wifi_ssid = connectionInfo.getSSID();
        if (!wifi_ssid.contains("Linksys00391") && !wifi_ssid.contains("CTWifi")){
            infoDisplay.setText("Make Sure You're Connected to Linksys00391 or CTWifi");
            return false;
        }







        if (ipAddressInput.contains("192.168.") && portAddressInput.equals("8888")){

            Log.i("tag", "Starting Client Thread");

            TimeUnit.SECONDS.sleep(2);
            infoDisplay.setText("Starting Connection with Master");


            return true;
        }

        infoDisplay.setText("Unable to Validate. Try again...");

        return false;

    }







}
