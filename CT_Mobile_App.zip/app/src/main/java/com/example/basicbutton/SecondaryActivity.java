package com.example.basicbutton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SecondaryActivity extends AppCompatActivity {

    Button buttonNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);

        buttonNext = (Button) findViewById(R.id.nextButton);

        buttonNext.setOnClickListener(buttonNextClickListener);
    }

    View.OnClickListener buttonNextClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.out.println("hello world! Button Click!");
            openMainActivity();
        }
    };

    private void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
